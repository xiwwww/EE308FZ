// 页面路径：store/index.js
import {
	createStore
} from 'vuex'
import Request from '../util/util'
const store = createStore({
	state: { //存放状态
		"pid": '',
		"name": '',
		"blance": '',
		"phoneNumber": '',
		statistic: {
			"couponNum": 0,
			"complaintNum": 0,
			"rideNum": 0
		}
	},
	mutations: {
		login(state, user) {
			console.log(user);
			state.pid = user.pid
			state.name = user.name
			state.blance = user.blance
			state.phoneNumber = user.phoneNumber
			// state.companyId = user.companyId
		},
		updateUserInfo(state, user) {
			// console.log(state);
			state.pid = user.pid
			state.name = user.name
			state.blance = user.blance
			state.phoneNumber = user.phoneNumber
			// state.companyId = user.companyId
		},
		logout(state) {
			state = {
				"pid": '',
				"name": '',
				"blance": '',
				"phoneNumber": '',
				statistic: {
					"couponNum": 0,
					"complaintNum": 0,
					"rideNum": 0
				}
			}
		},
		updateStatistic(state, statistic) {
			state.statistic = statistic

		}
	},
	actions: {
		async fetchUserInfo(context) {
			let data = await Request({
				method: "POST",
				url: '/passenger/fetchUserInfo',
				data: {
					"pid": context.state.pid
				}
			});
			if (data.errCode == 0) {
				context.commit("updateUserInfo", data.data)
				context.dispatch("fetchStatisticInfo")
			}
		},

		async fetchStatisticInfo(context) {
			let data = await Request({
				method: "POST",
				url: '/passenger/getStatistic',
				data: {
					"pid": context.state.pid
				}
			});
			if (data.errCode == 0) {
				context.commit("updateStatistic", data.data)
			}
		}


	}
})

export default store
