<template>
	<view>
		<uni-card :is-shadow="false" is-full>
			<text class="uni-h6">优惠券列表</text>
		</uni-card>
		<uni-section title="已购买优惠券" type="line">
			<view v-for="coupon in coupons" :key="coupon.cid">
				<uni-card :title="`${coupon.description}`" :extra="'剩余：'+coupon.num">
					<text class="uni-body">优惠券号：{{coupon.cid}}</text>
					<br />
					<!-- <text class="uni-body">&nbsp;&nbsp;&nbsp;原价: {{ride.originPrice}}</text>
					<br /> -->
					<text class="uni-body">最低金额: {{coupon.restcrtion}}</text>
					<br /> 
					<text class="uni-body">购买时间: {{coupon.create_time}}</text>
					<br />
					<text class="uni-body">有效时间: {{coupon.validate}}</text>
				</uni-card>
			</view>
		</uni-section>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex'
	export default {
		computed: {
			...mapState(["pid"])
		},
		data() {
			return {
			coupons:[]
			}
		},
		created() {
			this.getCoupons()
		},
		methods: {
			async getCoupons() {
			
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/checkCoupons',
					data: {
						"key":this.pid
					}
				});
				if (data.errCode == 0) {
					this.coupons = data.data
					console.log(this.coupons);
				}
			}
		}
	}
</script>

<style>

</style>
