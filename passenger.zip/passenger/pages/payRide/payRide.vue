<template>
	<uni-card :is-shadow="false" is-full>
		<text class="uni-h6">以下为你最近一次未支付的订单,系统显示为原价，支付后系统将选取折扣最大的优惠券为您使用</text>
	</uni-card>
	<uni-section title="起点" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.start">
		</uni-easyinput>
	</uni-section>
	<uni-section title="终点" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.destinition">
		</uni-easyinput>
	</uni-section>
	<uni-section title="原价" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.originPrice">
		</uni-easyinput>
	</uni-section>
	<uni-section title="车牌号" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.license">
		</uni-easyinput>
	</uni-section>
	<button @click="payRide()">支付订单</button>

</template>

<script>
	export default {
		onLoad: function(option) { //option为object类型，会序列化上个页面传递的参数
			this.ride.pid = option.pid
			console.log(this.ride);
			this.getUnpayCheck()
		},
		data() {
			return {
				ride: {
					start:null
				}
			};
		},
		created() {
			
		},
		methods: {
			// async init(){
			// 	if(this.ride.start==null){
					
			// 	}
			// },
			async getUnpayCheck(){
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/checkNotPayRide',
					data: {
						"pid": this.ride.pid
					}
				});
				if (data.errCode == 0) {
					this.ride = data.data
					}
			},
			async completePay(){
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/PayRide',
					data: this.ride
				});
				if (data.errCode == 0) {
					
					uni.showModal({
						title: "支付完成支付金额为",
						content: "折后金额为" + data.data.finalPrice,
						success: (res) => {
				
							uni.switchTab({
								url: "/pages/index/index"
							})
				
						}
					})
				} else if (data.errCode == 22) {
					uni.showModal({
						title: "支付失败",
						content: "金额不足，是否前往充值页面",
						success: (res) => {
							if (res.confirm) {
								uni.switchTab({
									url: "/pages/info/info"
								})
							}
						}
					})
				}
			},
			async payRide() {
				uni.showModal({
					title:"确认支付吗",
					content:"点击确认完成支付",
					success: (res) => {
						if(res.confirm){
							this.completePay()
						}
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	button {
		width: 50%;
		margin: 0 auto;
	}

	.example-body {
		background-color: #fff;
		padding: 10px;
	}

	.text {
		font-size: 12px;
		color: #666;
		margin-top: 5px;
	}

	.uni-px-5 {
		padding-left: 10px;
		padding-right: 10px;
	}

	.uni-pb-5 {
		padding-bottom: 10px;
	}
</style>
