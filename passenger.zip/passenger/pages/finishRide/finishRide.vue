<template>
	<uni-card :is-shadow="false" is-full>
		<text class="uni-h6">订单列表，记录了过去您完成的订单</text>
	</uni-card>
	<uni-section title="订单列表" type="line">
	<ride-list :rides="rides"></ride-list>
	</uni-section>
</template>

<script>
	import rideList from './component/RideList.vue'
	import {
		mapState
	} from 'vuex'
	export default {
		components: {
			rideList
		}
		,
		data() {
			return {
				rides: []
			}
		},
		computed: {
			...mapState(["pid"])
		},
		onShow() {
			this.getRides()
		},
		methods: {
			async getRides() {

				let data = await this.$Request({
					method: "POST",
					url: '/passenger/getFinishedRidesInfo',
					data: {
						"pid":this.pid
					}
				});
				if (data.errCode == 0) {
					this.rides = data.data.reverse()
				}
			}
		}
	}
</script>

<style>

</style>
