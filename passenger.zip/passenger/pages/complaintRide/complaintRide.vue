<template>
	<view>
		<uni-card :is-shadow="false" is-full>
			<text class="uni-h6">投诉成功后，退款将返回您的账户之中，投诉理由不可为空</text>
		</uni-card>
		<uni-section title="投诉订单号"  type="line" padding>
			<uni-easyinput errorMessage v-model="form.rid" disabled="" @input="input"></uni-easyinput>
		</uni-section>
		<uni-section title="投诉原因" type="line" padding>
			<uni-easyinput errorMessage v-model="form.description" focus placeholder="请输入内容" @input="input" type="textarea"></uni-easyinput>
		</uni-section>
		<button @click="submit()">Submit</button>
	</view>
</template>

<script>
	export default {
		onLoad:function(option) { //option为object类型，会序列化上个页面传递的参数
			this.form.rid = option.rid
			},
		data() {
			return {
				form:{
					rid:'',
					description:''
				}
			};
		},
		
		methods:{
			async submit(){
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/complaintRide',
					data:this.form
				});
				if (data.errCode == 0) {
					uni.navigateBack()
				}
			}
		}
	}
</script>

<style lang="scss">

</style>
