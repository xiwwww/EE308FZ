<template>
	<uni-section title="起点" type="line" padding>
		<uni-easyinput class="uni-mt-5" suffixIcon="search" v-model="form.ride.start" placeholder="请点击右侧图标选择起点"
			:disabled="true" @iconClick="start()">
		</uni-easyinput>
	</uni-section>
	<uni-section title="终点" type="line" padding>
		<uni-easyinput class="uni-mt-5" suffixIcon="search" v-model="form.ride.destinition" placeholder="请点击右侧图标选择终点"
			:disabled="true" @iconClick="end()">
		</uni-easyinput>
	</uni-section>
	<!-- <view>
		<button type="primary" @click="start()">地图选点</button>
	</view> -->
	<uni-section title="是否预约" type="line">
		<view class="uni-px-5 uni-pb-5">
			<uni-data-checkbox :localdata="preOrderList" v-model="preOrder"></uni-data-checkbox>
		</view>
	</uni-section>
	<uni-section title="预约时间" type="line" v-show="preOrder"></uni-section>
	<view class="example-body" v-show="preOrder">
		<uni-datetime-picker v-model="startTime" />
	</view>
	<button @click="submit()">开始打车</button>
</template>

<script>
	import {
		mapState
	} from 'vuex'
	// import {QQMapWX} from "@/util/qqmap-wx-jssdk.js"

	var QQMapWX = require("../../util/qqmap-wx-jssdk.js")
	const key = 'BAQBZ-DM2WJ-L6BFN-KRRTJ-7HB75-TXFCZ'; //使用在腾讯位置服务申请的key
	const referer = 'rail-hailing-p'; //调用插件的app的名称
	const category = '生活服务,娱乐休闲';

	export default {
		computed: {
			...mapState(["pid"]),
			location() {
				JSON.stringify({
					latitude: this.latitude,
					longitude: this.longitude
				})
			}
		},
		data() {
			return {
				form: {
					start: {
						x: '',
						y: ''
					},
					end: {
						x: '',
						y: ''
					},
					ride: {
						pid: '',
						start: '',
						destinition: '',
						originPrice: 0
					}
				},
				startTime: '',
				// 经度
				latitude: 0,
				preOrder: 0,
				// 纬度
				longitude: 0,
				from: {},
				to: {},
				preOrderList: [{
					text: '预约打车',
					value: 1
				}, {
					text: '即时打车',
					value: 0
				}],
			}
		},
		created() {
			this.check()
			// 获取当前的位置信息
			uni.getLocation({
				type: 'wgs84',
				success: (res) => {
					// console.log(res);
					this.latitude = res.latitude
					this.longitude = res.longitude
				}
			})
		},
		methods: {
			async check() {

				let data = await this.$Request({
					method: "POST",
					url: '/passenger/checkNotPayRide',
					data: {
						"pid": this.pid
					}
				});
				if (data.errCode == 0) {
					// let ride = JSON.stringify({
					// 	start: data.data.start,
					// 	destinition: data.data.destinition,
					// 	license: data.data.license,
					// 	originPrice: data.data.originPrice,
					// 	pid: this.pid // 可以直接使用系统传来的pid
					// })
					uni.showModal({
						title: "存在未支付订单",
						content: "点击确定前去支付",
						success: (res) => {
							if (res.confirm) {
								uni.navigateTo({
									url: "/pages/payRide/payRide?pid=" + this.pid
								})
							} else {
								uni.switchTab({
									url: "/pages/info/info"
								})
							}
						}
					})

				} else if (data.errCode == 23) {
					let data1 = await this.$Request({
						method: "POST",
						url: '/passenger/checkpreOrderRide',
						data: {
							"pid": this.pid
						}
					});
					if (data1.errCode == 0) {

						let ride = JSON.stringify({
							start: data1.data.start,
							destinition: data1.data.destinition,
							startTime: data1.data.startTime,
							startPos: data1.data.startPos,
							pid: this.pid // 可以直接使用系统传来的pid
						})
						//跳转预定页面
						uni.showModal({
							title: "存在预定订单",
							content: "点击确定前往订单页面",
							success: (res) => {
								if (res.confirm) {
									uni.navigateTo({
										url: "/pages/preOrder/preOrder?ride=" + ride
									})
								} else {
									uni.switchTab({
										url: "/pages/info/info"
									})
								}
							}
						})
					} else if (data1.errCode == 24) {
						let data2 = await this.$Request({
							method: "POST",
							url: '/passenger/getCurrentRide',
							data: {
								"pid": this.pid
							}
						});
						if (data2.errCode == 0) {
							//跳转订单页面
							let ride = JSON.stringify({
								start: data2.data.start,
								destinition: data2.data.destinition,
								startTime: data2.data.startTime,
								license: data2.data.license,
								pid: this.pid // 可以直接使用系统传来的pid
							})
							uni.showModal({
								title: "存在正在进行的订单",
								content: "点击确定前往订单页面",
								success: (res) => {
									uni.navigateTo({
										url: "/pages/ridePage/ridePage?Ride=" + ride
									})
								}
							})
						} else {
							return true
						}
					}
				}
			},
			async addPreOrder() {
				let lstartTime = this.startTime.split(" ").join("T")
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/addPreOrderRide',
					data: {
						pid: this.pid,
						start: this.form.ride.start,
						destinition: this.form.ride.destinition,
						startTime: lstartTime,
						originPrice: this.form.ride.originPrice,
						startPos: this.form.start
					}
				});
				if (data.errCode == 0) {
					let ride = JSON.stringify({
						start: this.form.ride.start,
						destinition: this.form.ride.destinition,
						startTime: this.startTime,
						pid: this.pid
					})
					uni.showModal({
						title: "添加成功",
						content: "是否进入预约页面",
						success: (res) => {
							if (res.confirm) {
								uni.navigateTo({
									url: "/pages/preOrder/preOrder?ride=" + ride
								})
							} else {
								uni.switchTab({
									url: "/pages/info/info"
								})
							}
						}
					})
				}
			},
			async addOrder() {

				let data = await this.$Request({
					method: "POST",
					url: '/passenger/addOrder',
					data: {
						pid: this.pid,
						start: this.form.ride.start,
						destinition: this.form.ride.destinition,
						startPos: this.form.start,
						originPrice: this.form.ride.originPrice
					}
				});
				if (data.errCode == 0) {
					uni.navigateTo({
						url: "/pages/findRide/findRide"
					})
				}
			},
			valid() {
				if (this.form.ride.start == '' || this.form.ride.destinition == '') {
					uni.showModal({
						title: "地点错误",
						content: "请验证起点与终点是否选择"
					})
					return
				}

				if (this.preOrder == 1 && this.startTime != '' || this.preOrder == 0) {
					return true
				} else {
					uni.showModal({
						title: "预约时间不可为空",
						content: "请填写预约时间"
					})
				}

			},
			submit() {
				//为预约打车
				if (this.valid()) {
					if (this.preOrder == 1) {
						this.addPreOrder()
					} else {
						this.addOrder()
					}
				}

			},
			start() {
				wx.chooseLocation({
					url: 'plugin://chooseLocation/index?key=' + key + '&referer=' + referer + '&location=' +
						location + '&category=' + category,
					success: res => {
						this.form.ride.start = res.name
						this.form.start.x = res.longitude
						this.form.start.y = res.latitude
						this.from = {
							...res
						}
					}
				});
			},
			end() {
				wx.chooseLocation({
					url: 'plugin://chooseLocation/index?key=' + key + '&referer=' + referer + '&location=' +
						location + '&category=' + category,
					success: res => {
						this.form.ride.destinition = res.name
						this.form.end.x = res.longitude
						this.form.end.y = res.latitude
						this.to = {
							...res
						}
						this.getOriginPrice()
					}
				});
			},
			async getOriginPrice() {
				//通过腾讯地图接口
				// var QQMapWX = require('/util/qqmap-wx-jssdk.js');
				var qq = new QQMapWX({
					key: key // 必填
				});
				// 实例化API核心类
				await qq.calculateDistance({
					//mode: 'driving',//可选值：'driving'（驾车）、'walking'（步行），不填默认：'walking',可不填
					//from参数不填默认当前地址
					//获取表单提交的经纬度并设置from和to参数（示例为string格式）
					from: this.from || '', //若起点有数据则采用起点坐标，若为空默认当前地址
					to: [this.to], //终点坐标
					success: (res) => { //成功后的回调
						if (res.status == 0) {
							console.log(this.form);
							this.form.ride.originPrice = res.result.elements[0].distance * 3.0 / 1000
						}
					},
					fail: function(error) {
						console.error(error);
					},
					complete: function(res) {
						console.log(res);
					}
				})
			}
		},
	}
</script>

<style lang="scss">
	button {
		width: 50%;
		margin: 0 auto;
	}

	.example-body {
		background-color: #fff;
		padding: 10px;
	}

	.text {
		font-size: 12px;
		color: #666;
		margin-top: 5px;
	}

	.uni-px-5 {
		padding-left: 10px;
		padding-right: 10px;
	}

	.uni-pb-5 {
		padding-bottom: 10px;
	}
</style>
