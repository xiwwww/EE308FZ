<template>
	<view>
		<uni-card :is-shadow="false" is-full>
			<text class="uni-h6">优惠卷商城</text>
		</uni-card>
		<uni-section title="可购买优惠券" type="line">
			<view v-for="coupon in coupons" :key="coupon.cid">
				<uni-card :title="`${coupon.description}`" :extra="'总价：'+(coupon.price*coupon.num)">
					<text class="uni-body">优惠券号：{{coupon.cid}}</text>
					<br />
					<text class="uni-body">单价: {{coupon.price}}</text>
					<br />
					<text class="uni-body">有效时间: {{coupon.validate}}</text>
					<view slot="actions" style="display: flex;flex-direction: row;">
						<view style="width: 50%;">
							<uni-number-box :min="1" :max="20" v-model="coupon.num" />
						</view>
						<view style="width: 50%;" @click="buy(coupon)">

							<text
								style="font-size: 32rpx;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;购买</text>
						</view>
					</view>
				</uni-card>
			</view>
		</uni-section>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex'
	export default {
		computed: {
			...mapState(["pid"])
		},
		data() {
			return {
				coupons: [],
				pageIndex: 1
			}
		},
		created() {
			this.getCoupons()
		},
		onReachBottom() {
			this.pageIndex++
			this.getCoupons()
		},
		methods: {
			async getCoupons() {

				let data = await this.$Request({
					method: "POST",
					url: '/passenger/getCouponsInfo',
					data: {
						pid: this.pid,
						pageIndex: this.pageIndex,
						pageSize: 6
					}
				})
				if (data.errCode == 0) {
					data.data.forEach(item=>{
						item.num=1
					})
					this.coupons = this.coupons.concat(data.data)
				}
			},

			async buy(coupon) {
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/passengerBuyCoupons',
					data: {
						pid: this.pid,
						cid: coupon.cid,
						nums: coupon.num
					}
				});
				if (data.errCode == 0) {
					uni.showToast({
						title:"购买成功"
					})
				}
			}
		}
	}
</script>

<style>

</style>
