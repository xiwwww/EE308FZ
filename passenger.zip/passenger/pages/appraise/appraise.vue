<template>
	<uni-card :is-shadow="false" is-full>
		<text class="uni-h6">您的评价将会给司机带来莫大的动力</text>
	</uni-card>
	<uni-section title="评价订单号"  type="line" padding>
		<uni-easyinput  v-model="form.rid" disabled="" @input="input"></uni-easyinput>
	</uni-section>
	<uni-section title="司机态度"  type="line" padding>
		<uni-rate allow-half v-model="form.attitude" />
	</uni-section>
	<uni-section title="车辆卫生" type="line" padding>
		<uni-rate allow-half v-model="form.hygiene" />
	</uni-section>
	<uni-section title="乘坐体验"  type="line" padding>
		<uni-rate allow-half v-model="form.experience" />
	</uni-section>
	<uni-section title="评语"  type="line" padding>
		<uni-easyinput type="textarea" autoHeight v-model="form.comment" placeholder="请输入内容"></uni-easyinput>
	</uni-section>
	<button @click="submit()">Submit</button>
	
</template>

<script>
	export default {
		onLoad:function(option) { //option为object类型，会序列化上个页面传递的参数
			this.form.rid = option.rid
			},
		data() {
			return {
				form:{
					rid:'',
					attitude:3,
					hygiene:3,
					experience:3,
					comment:''
				}
			};
		},
		methods:{
			async submit(){
				// console.log(this.form);
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/appriseRide',
					data:this.form
				});
				if (data.errCode == 0) {
					uni.navigateBack()
				}
			}
		}
	}
</script>

<style>

</style>
