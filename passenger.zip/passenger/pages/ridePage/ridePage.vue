<template>
	<uni-card :is-shadow="false" is-full>
		<text class="uni-h6">您的订单正在进行中，请到达地点后选择完成订单</text>
	</uni-card>
	<uni-section title="起点" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.start">
		</uni-easyinput>
	</uni-section>
	<uni-section title="终点" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.destinition">
		</uni-easyinput>
	</uni-section>
	<uni-section title="原价" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.originPrice">
		</uni-easyinput>
	</uni-section>
	<uni-section title="当前司机的评分" type="line" padding v-if="driverRate!=null">
		<uni-rate allow-half v-model="driverRate" />
	</uni-section>
	<uni-section title="车牌号" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.license">
		</uni-easyinput>
	</uni-section>
	<button @click="finishRide()">行程完成</button>

</template>

<script>
	import {
		mapState
	} from 'vuex'

	export default {
		computed: {
			...mapState(["pid", "blance", "name"])
		},
		data() {
			return {
				ride: {
					pid: '',
					start: '',
					destinition: '',
					license: null,
				},
				start: {
					x: '',
					y: ''
				},
				driverRate: null,
				status: 0,
				gPrice: null
			};
		},
		created() {
			this.init()
		},
		methods: {
			// async initConnection() {
			// 	let that = this
			// 	// uni.closeSocket()
			// 	//初始化查询信息，使用ws初始化连接
			// 	uni.connectSocket({
			// 		url: 'ws://192.168.31.214:8082/ws/PassengerOrder',
			// 	});

			// 	uni.onSocketOpen(function(res) {
			// 		that.sendMessage({
			// 			action: "initConnection",
			// 			data: {
			// 				pid: that.pid
			// 			}
			// 		})

			// 	})

			// },
			async finishRide() {
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/finishRide',
					data: {
						"pid": this.pid
					}
				});
				if (data.errCode == 0) {
					uni.showModal({
						title: "订单完成",
						content: "点击确认现在前往支付页面",
						success: (res) => {
							if (res.confirm) {
								uni.navigateTo({
									url: "/pages/payRide/payRide?pid=" + this.pid
								})
							} else {
								uni.switchTab({
									url: "/pages/info/info"
								})
							}
						}
					})
					//调位置服务的接口
				}
			},
			async init() {
				await this.getRide()
				// this.initConnection()
			},
			async getRide() {
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/getCurrentRide',
					data: {
						"pid": this.pid
					}
				});
				if (data.errCode == 0) {
					this.ride.start = data.data.start
					this.ride.destinition = data.data.destinition
					this.ride.pid = data.data.pid
					this.ride.originPrice = data.data.originPrice
					this.ride.license = data.data.license
					this.start = data.data.startPos
					this.getDriverRate()
					//调位置服务的接口
				}else{
					uni.reLaunch({
						url:"/pages/index/index"
					})
				}
			},
			async getDriverRate() {
				if (this.ride.license != '' && this.ride.license != null) {
					let data = await this.$Request({
						method: "POST",
						url: '/passenger/getDriverRate',
						data: {
							"license": this.ride.license
						}
					});
					if (data.errCode == 0) {
						this.driverRate = data.data
					}
				}
			},
			// async sendMessage(object) {
			// 	// console.log(object);
			// 	let message = JSON.stringify(object)
			// 	uni.sendSocketMessage({
			// 		data: message,
			// 	});
			// }


		}


	}
</script>

<style lang="scss">
	button {
		width: 50%;
		margin: 0 auto;
	}

	.example-body {
		background-color: #fff;
		padding: 10px;
	}

	.text {
		font-size: 12px;
		color: #666;
		margin-top: 5px;
	}

	.uni-px-5 {
		padding-left: 10px;
		padding-right: 10px;
	}

	.uni-pb-5 {
		padding-bottom: 10px;
	}
</style>
