<template>
	<uni-card :is-shadow="false" is-full>
		<text class="uni-h6">以下为你预约的订单,到达指定时间后系统将自动开始为您寻找附近司机，您可提前取消预约</text>
	</uni-card>
	<uni-section title="起点" type="line" padding>
		<uni-easyinput class="uni-mt-5"  v-model="ride.start" :disabled="true">
		</uni-easyinput>
	</uni-section>
	<uni-section title="终点" type="line" padding>
		<uni-easyinput class="uni-mt-5"  v-model="ride.destinition" :disabled="true" >
		</uni-easyinput>
	</uni-section>
	<uni-section title="预约时间" type="line"></uni-section>
	<view class="example-body">
		<uni-easyinput class="uni-mt-5" :value="ride.showStartTime" :disabled="true"/>
	</view>
	<button @click="cancelPreorder()">取消预约</button>

</template>

<script>
	export default {
		onLoad: function(option) { //option为object类型，会序列化上个页面传递的参数

			let ride = JSON.parse(option.ride)
			// console.log(ride);
			this.ride = {
				...ride
			}
			this.ride.showStartTime = ride.startTime.substring(0,10)+' '+ride.startTime.substring(11,19);
		},
		data() {
			return {
				ride: {},
				
			};
		},
		created() {
			this.cursor()
		},
		
		methods: {
			validate(){
				let preDate = new Date(this.ride.showStartTime);
				if(Date.now()>preDate.getTime()){
					return true
				}else{
					return false
				}
			},
			cursor(){
				if(!this.validate()){
					//三秒后再次询问
					setTimeout(()=>{
						this.cursor()
					},3000)
				}else{
					this.preOrderOnTime()
				}
		
			},
			async cancelPreorder() {
				uni.showModal({
					title: "取消确认",
					content: "确认取消订单吗",
					success: async (res) => {
						if (res.confirm) {
							let data = await this.$Request({
								method: "POST",
								url: '/passenger/cancelPreorder',
								data: this.ride
							});
							if (data.errCode == 0) {
								uni.switchTab({
									url: "/pages/index/index"
								})
							}
						}


					}
				})
			},
			async preOrderOnTime() {
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/convertPreOrder',
					data: this.ride
				});
				if (data.errCode == 0) {
					uni.reLaunch({
						url:"/pages/findRide/findRide"
					})
				}
			},


		}
	}
</script>

<style lang="scss">
	button {
		width: 50%;
		margin: 0 auto;
	}

	.example-body {
		background-color: #fff;
		padding: 10px;
	}

	.text {
		font-size: 12px;
		color: #666;
		margin-top: 5px;
	}

	.uni-px-5 {
		padding-left: 10px;
		padding-right: 10px;
	}

	.uni-pb-5 {
		padding-bottom: 10px;
	}
</style>
