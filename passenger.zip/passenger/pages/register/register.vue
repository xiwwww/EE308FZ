// An highlighted block
<template>
	<view class="content">
		<view class="avatorWrapper">
			<view class="avator">
				<image class="img" src="/static/logo.png" mode="widthFix"></image>
			</view>
		</view>
		<view class="form">
			<view class="inputWrapper">
				<input class="input" type="text" v-model="form.phoneNumber" placeholder="请输入手机号" />
			</view>
			<view class="inputWrapper">
				<input class="input" type="text" v-model="form.name" placeholder="请输入用户名" />
			</view>
			<view class="inputWrapper">
				<input class="input" type="password" v-model="form.password" placeholder="请输入密码" />
			</view>
			<view class="inputWrapper">
				<input class="input" type="password" v-model="form.cpassword" placeholder="请再次输入密码" />
			</view>
			<view class="loginBtn" @click="submit">
				<text class="btnValue">注册</text>
			</view>
		
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				form: {
					phoneNumber: '13097271525',
					name: '测试用户',
					password: '123456',
					cpassword: '123456'
				}
			}
		},
		
		methods: {
			async submit() {
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/register',
					data: this.form
				});
				if (data.errCode == 0) {
					uni.showModal({ // 弹框询问是否进行下一步事件
						title: '提示',
						content: '您的用户ID为'+data.data,
						success:async (res) => {
							uni.reLaunch({
								url: '/pages/login/login'
							});
						}
					});
				
				}

			}
		}
	}
</script>

<style>
	.content {
		background: #377EB4;
		width: 100vw;
		height: 100vh;
	}

	.avatorWrapper {
		height: 30vh;
		width: 100vw;
		display: flex;
		justify-content: center;
		align-items: flex-end;
	}

	.avator {
		width: 200upx;
		height: 200upx;
		overflow: hidden;
	}

	.avator .img {
		width: 100%
	}

	.form {
		padding: 0 100upx;
		margin-top: 80px;
	}

	.inputWrapper {
		width: 100%;
		height: 80upx;
		background: white;
		border-radius: 20px;
		box-sizing: border-box;
		padding: 0 20px;
		margin-top: 25px;
	}

	.inputWrapper .input {
		width: 100%;
		height: 100%;
		text-align: center;
		font-size: 15px;
	}

	.loginBtn {
		width: 100%;
		height: 80upx;
		background: #77B307;
		border-radius: 50upx;
		margin-top: 50px;
		display: flex;
		justify-content: center;
		align-items: center;

	}

	.loginBtn .btnValue {
		color: white;
	}

	.forgotBtn {
		text-align: center;
		color: #EAF6F9;
		font-size: 15px;
		margin-top: 20px;
	}
</style>
