<template>
	<uni-card :is-shadow="false" is-full>
		<text class="uni-h6">正在为您寻找附近合适的车辆</text>
	</uni-card>
	<uni-section title="起点" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.start">
		</uni-easyinput>
	</uni-section>
	<uni-section title="终点" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.destinition">
		</uni-easyinput>
	</uni-section>
	<uni-section title="原价" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.originPrice">
		</uni-easyinput>
	</uni-section>
	<uni-section title="预估价" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" :value="gPrice" v-if="gPrice!=null">
		</uni-easyinput>
	</uni-section>
	<uni-section title="车牌号" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.license">
		</uni-easyinput>
	</uni-section>
	<button @click="back()">取消</button>

</template>

<script>
	import {
		mapState
	} from 'vuex'

	export default {
		computed: {
			...mapState(["pid", "blance", "name"])
		},
		data() {
			return {
				ride: {
					pid: '',
					start: '',
					destinition: '',
					license: null,
				},
				start: {
					x: '',
					y: ''
				},
				driverRate: '',
				gPrice: null
			};
		},
		created() {
			this.init()
		},
		methods: {
			async init() {
				await this.getRide()
				this.initConnection()
			},
			async getRide() {
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/getOrder',
					data: {
						"pid": this.pid
					}
				});
				if (data.errCode == 0) {
					this.ride.start = data.data.start
					this.ride.destinition = data.data.destinition
					this.ride.pid = data.data.pid
					this.ride.originPrice = data.data.originPrice
					this.start = data.data.startPos
					this.getGPrice()
				}
			},
			async getGPrice() {
				let data = await this.$Request({
					method: "POST",
					url: '/passenger/getBestCoupon',
					data: {
						"pid": this.ride.pid,
						"originPrice": this.ride.originPrice
					}
				});
				if (data.errCode == 0) {
					this.gPrice = data.data.finalPrice
				}
			},
			async back() {
				this.sendMessage({
					action: "cancelOrder",
					data:{
						pid:this.pid
					}
				})
				uni.closeSocket()
				uni.reLaunch({
					url: "/pages/index/index"
				})
			},
			async initConnection() {
				let that = this
				// uni.closeSocket()
				//初始化查询信息，使用ws初始化连接
				uni.connectSocket({
					url: 'ws://192.168.31.214:8082/ws/PassengerOrder',
				});

				uni.onSocketOpen(function(res) {
					that.sendMessage({
						action: "initConnection",
						data: {
							pid: that.pid
						}
					})
					//加入乘客队列，初始化搜索信息
					that.searchCar()
				})
				uni.onSocketMessage(function(res) {
					console.log('收到服务器内容：' + res.data);
					let data = JSON.parse(res.data);
					if (data.action == "rideReady") {
						uni.closeSocket()
						uni.reLaunch({
							url: "/pages/ridePage/ridePage"
						})
					}
				});
			},
			async searchCar() {
				let that = this
				// uni.closeSocket()
				//初始化查询信息，使用ws初始化连接
				that.sendMessage({
					action: "passengerSearchCar",
					data: {
						pid: that.ride.pid
						
					}
				})
			},
			async sendMessage(object) {
				// console.log(object);
				let message = JSON.stringify(object)
				uni.sendSocketMessage({
					data: message,
				});
			}

		},
	}
</script>

<style lang="scss">
	button {
		width: 50%;
		margin: 0 auto;
	}

	.example-body {
		background-color: #fff;
		padding: 10px;
	}

	.text {
		font-size: 12px;
		color: #666;
		margin-top: 5px;
	}

	.uni-px-5 {
		padding-left: 10px;
		padding-right: 10px;
	}

	.uni-pb-5 {
		padding-bottom: 10px;
	}
</style>
