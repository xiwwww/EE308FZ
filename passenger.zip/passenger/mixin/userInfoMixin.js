import store from '/store'
import {
		mapState
	} from 'vuex'
const baseMixin = {
    computed:{
		...mapState(["pid"])
	},
    methods: {
        
    }
}

export default userInfoMixin;
