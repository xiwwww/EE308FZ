// 页面路径：store/index.js
import {
	createStore
} from 'vuex'
import Request from '../util/util'
const store = createStore({
	state: { //存放状态
		"did": '',
		"name": '',
		"blance": '',
		"phoneNumber": '',
		"statistic": {
			"driverRate": 0,
			"complaintNum": 0,
			"rideNum": 0
		}
	},
	mutations: {
		login(state, user) {
			console.log(user);
			state.did = user.did
			state.name = user.name
			state.blance = user.blance
			state.phoneNumber = user.phoneNumber
			// state.companyId = user.companyId
		},
		updateUserInfo(state, user) {
			// console.log(state);
			state.did = user.did
			state.name = user.name
			state.blance = user.blance
			state.phoneNumber = user.phoneNumber
			// state.companyId = user.companyId
		},
		logout(state) {
			state = {
				"did": '',
				"name": '',
				"blance": '',
				"phoneNumber": '',
				statistic: {
					"driverRate": 0,
					"complaintNum": 0,
					"rideNum": 0
				}
			}
		},
		updateStatistic(state, statistic) {
			state.statistic = statistic

		}
	},
	actions: {
		async fetchUserInfo(context) {
			let data = await Request({
				method: "POST",
				url: '/fetchUserInfo',
				data: {
					"did": context.state.did
				}
			});
			if (data.errCode == 0) {
				context.commit("updateUserInfo", data.data)
				context.dispatch("fetchStatisticInfo")
			}
		},

		async fetchStatisticInfo(context) {
			let data = await Request({
				method: "POST",
				url: '/fetchStatistic',
				data: {
					"did": context.state.did
				}
			});
			if (data.errCode == 0) {
				context.commit("updateStatistic", data.data)
			}
		}


	}
})

export default store
