<template>
	<view>
		<uni-card :is-shadow="false" is-full>
			<text class="uni-h6">评价列表，乘客的打分分为三个部分，显示评分为所有评价综合评分的平均值</text>
		</uni-card>
		<uni-section title="收到的评价" type="line">
			<view v-for="apprise in apprises" :key="apprise.rid">
				<uni-card :title="`订单号：${apprise.rid}`" :extra="'综合评分：'+apprise.avag_rate">
					<text class="uni-body">态度评分: {{apprise.attitude}}</text>
					<br />
					<text class="uni-body">卫生评分: {{apprise.hygiene}}</text>
					<br />
					<text class="uni-body">体验评分: {{apprise.experience}}</text>
					<br />
					<text class="uni-body">评价: {{apprise.comment}}</text>
					
				</uni-card>
			</view>
		</uni-section>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex'
	export default {
		computed: {
			...mapState(["did"])
		},
		data() {
			return {
				apprises: [],
				pageIndex: 1
			}
		},
		created() {
			this.getApprise()
		},
		onReachBottom() {
			this.getApprise()
		},
		methods: {
			async getApprise() {
				let data = await this.$Request({
					method: "POST",
					url: '/getApprise',
					data: {
						did: this.did,
						pageIndex: this.pageIndex,
						pageSize: 6
					}
				})
				if (data.errCode == 0) {
					// data.data.forEach(item => {
					// 	item.num = 1
					// })
					this.apprises = this.apprises.concat(data.data)
					// console.log(this.apprises);
					this.pageIndex++
				}
			}
		}
	}
</script>

<style>

</style>
