<template>
	<uni-card :is-shadow="false" is-full>
		<text class="uni-h6" v-if="status==0">正在为您寻找附近合适的车辆</text>
		<text class="uni-h6" v-if="status==1">您的订单正在进行中，请到达地点后选择完成订单</text>
	</uni-card>
	<uni-section title="起点" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.start">
		</uni-easyinput>
	</uni-section>
	<uni-section title="终点" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.destinition">
		</uni-easyinput>
	</uni-section>
	<uni-section title="预估价" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.originPrice">
		</uni-easyinput>
	</uni-section>
	<uni-section title="乘客ID" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.pid">
		</uni-easyinput>
	</uni-section>
	<!-- 	<uni-section title="您的评分" type="line" padding >
		<uni-rate allow-half :value="statistic.driverRate" />
	</uni-section> -->
	<uni-section title="车牌号" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="ride.license">
		</uni-easyinput>
	</uni-section>
</template>

<script>
	import {
		mapState
	} from 'vuex'

	export default {
		computed: {
			...mapState(["did"])
		},
		data() {
			return {
				ride: {

				},
				
			};
		},
		onLoad: function(option) {
			this.ride.license = option.license
			this.getRide()
			// this.check()
		},
		created() {

		},
		methods: {
			async check() {
				let that = this
				//初始化查询信息，使用ws初始化连接
				// uni.closeSocket()
				await uni.connectSocket({
					url: 'ws://192.168.31.214:8082/ws/carFindOrder',
					fail: (res) => {
						uni.showModal({
							title: "网络错误",
							content: "当前无法使用",
							success: (res) => {
								uni.navigateBack()
							}
						})
					},
				
				});
				//监听连接建立成功后
				uni.onSocketOpen(function(res) {
					that.socketOpen = true
					that.sendMessage({
						action: "initConnection",
						data: {
						license:that.ride.license	
						}
					})
				});
				// uni.onSocketClose((res)=>{
				// 	clearInterval(that.cursor)
				// })
				//监听连接建立成功后
				
				uni.onSocketMessage(function(res) {
					console.log('收到服务器内容：' + res.data);
					let data = JSON.parse(res.data);
					if (data.action == "finish") {
						uni.showModal({
							title: "订单已经完成",
							content: "是否继续接单",
							success: (res) => {
								if(res.confirm){
									uni.navigateTo({
									url: "/pages/ridePage/ridePage?license=" + that.form
										.car.license
								})
								}else{
									// uni.closeSocket()
									uni.reLaunch({
										url:"/pages/index/index"
									})
								}
							}
						})
					} 
				});


			},
			async getRide() {
				let data = await this.$Request({
					method: "POST",
					url: '/getCurrentRide',
					data: {
						did: this.did,
					}
				})
				if (data.errCode == 0) {
					this.ride = data.data
					this.check()
				}
			},
			//传递json类型的字符串{string:action,data:data}
			async sendMessage(object) {
				let message = JSON.stringify(object)
				
					console.log(message);
					uni.sendSocketMessage({
						data: message,
					});
				
			}

		}
	}
</script>

<style lang="scss">
	button {
		width: 50%;
		margin: 0 auto;
	}

	.example-body {
		background-color: #fff;
		padding: 10px;
	}

	.text {
		font-size: 12px;
		color: #666;
		margin-top: 5px;
	}

	.uni-px-5 {
		padding-left: 10px;
		padding-right: 10px;
	}

	.uni-pb-5 {
		padding-bottom: 10px;
	}
</style>
