<template>
	<view v-for="ride in rides" :key="ride.rid">
		<uni-card :title="`${ride.start}->${ride.destinition}`" :extra="ride.statusInfo">
			<text class="uni-body">订单号：{{ride.rid}}</text>
			<br />
			<text class="uni-body">&nbsp;&nbsp;交易价: {{ride.final_price}}</text>
			<br />
			<text class="uni-body">申诉原因: {{ride.description}}</text>
			<br />
			<text class="uni-body">订单创建时间: {{ride.create_time}}</text>
		</uni-card>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex'
	export default {
		computed: {
			...mapState(["did"])
		},
		data() {
			return {
				rides: []
			}
		},
		onShow() {
			this.getComplaints()
		},
		methods: {
			async getComplaints() {
				let data = await this.$Request({
					method: "POST",
					url: '/getComplaints',
					data: {
						did: this.did
					}
				});
				if (data.errCode == 0) {
					// console.log(data.data);	
					data.data.forEach(item => {
						switch (item.status) {
							case 0:
								item.statusInfo = "待审核";
								break;
							case 1:
								item.statusInfo = "已通过";
								break;
							case 2:
								item.statusInfo = "已驳回";
								break;
						}
					})
					this.rides = data.data.reverse()
				}
			}
		}
	}
</script>

<style>

</style>
