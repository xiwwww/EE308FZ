<template>
	<view v-for="ride in rides" :key="ride.rid">
		<uni-card :title="`${ride.start}->${ride.destinition}`" :extra="ride.license">
			<text class="uni-body">订单号：{{ride.rid}}</text>
			<br />
			<text class="uni-body">&nbsp;&nbsp;&nbsp;原价: {{ride.originPrice}}</text>
			<br />
			<text class="uni-body">实付价: {{ride.finalPrice}}</text>
			<br />
			<text class="uni-body">订单创建时间: {{ride.createTime}}</text>
			<br />
			<!-- <view slot="actions" style="display: flex;flex-direction: row;">
				<view style="width: 50%;display: block;" @click="actionsComplain(ride.rid)">
					<uni-icons type="color" size="18" color="#999"></uni-icons>
					<text
						style="font-size: 32rpx;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;投诉</text>
				</view>
				<view style="width: 50%;" @click="actionsApprise(ride.rid)">
					<uni-icons type="chatbubble" size="18" color="#999"></uni-icons>
					<text
						style="font-size: 32rpx;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;评论</text>
				</view>
			</view> -->
		</uni-card>
	</view>
</template>

<script>
	export default {
		props: {
			rides: []
		},
		methods: {
			actionsApprise(rid) {
				uni.navigateTo({
					url: '/pages/appraise/appraise?rid='+rid
				});
			},
			actionsComplain(rid){
				uni.navigateTo({
					url: '/pages/complaintRide/complaintRide?rid='+rid
				});
			}
		}
	}
</script>

<style>

</style>
