<template>
	<view class="wrapper">

		<view>
			<view class="top">
				<view class="center">
					<view class="center_top">
						<view class="center_img" >
							
							<image src='http://localhost:8082/IMG/logo.png'></image>
							
							<!-- <open-data type="userAvatarUrl" class="user_head"></open-data> -->
						</view>
						<view class="center_info" >
							<view class="center_name" style="font-size: 32rpx;">
								<!-- 这里可以放自己的名称图片 -->
								
								<view><text>用户名：{{name}}</text></view>
								<view><text>余额:  {{blance}}</text></view>
								
								<!-- <open-data class="nickname" type="userNickName"></open-data> -->
							</view>

						</view>

					</view>
					<!-- <view class="center_down">
						<view class="center_rank" @tap="toNone">
							<image class="rank_icon" src="@/static/icon/vip.png"></image>
							<text class="rank_text">我的排名</text>
						</view>
						<view class="center_score" @tap="toNone">
							<image class="rank_icon" src="../../static/points.png"></image>
							<text class="rank_text">我的积分</text>
						</view>
					</view> -->
				</view>
				<image src='@/static/waterflow.gif' mode='scaleToFill' class='gif-wave'></image>
			</view>
		</view>


		<!-- 统计 -->
		<view class="count">
			<!-- <view class="cell"> 8 <text style="color: #AAAAAA;">收藏店铺</text> </view> -->
			<view class="cell" @click="toFinishRide()"> {{statistic.rideNum}} <text style="color: #AAAAAA;">完成订单</text> </view>
			<view class="cell" @click="toApprise()"> {{statistic.driverRate}} <text style="color: #AAAAAA;">司机评分</text> </view>
			<view class="cell" @click="toComplaint()"> {{statistic.complaintNum}} <text style="color: #AAAAAA;">申诉订单</text> </view>
		</view>
		
		<view class="address icon-arrow" @click="registerCar()">
			车辆注册
		</view>
		<!-- 管理 -->
		<!-- <view class="address icon-arrow" @click="alterPassword()">
			修改密码
		</view> -->
		<view class="address icon-arrow" @click="quit()">
			退出登录
		</view>
		<!-- 其它 -->
		<view class="extra">
			<view @click="makePhone" class="item icon-arrow">联系客服</view>
			<button open-type="feedback" class="item icon-arrow">意见</button>
		</view>
	</view>

</template>

<script>
	import {
		mapState,mapActions,mapMutations
	} from 'vuex'


	export default {
		computed: {
			...mapState(["did","blance","name","statistic"])
		},

		data() {
			return {
				
			}
		},

		onShow() {
			this.fetchUserInfo()
		},
		methods: {
			...mapActions(["fetchStatisticInfo","fetchUserInfo"])
			,
			...mapMutations(["logout"]),
			alterPassword(){
				uni.showToast({
					title:"失败",
					content:"暂时还不支持这个功能哦"
				})
			},
			toComplaint(){
				uni.navigateTo({
					url: "/pages/complaint/complaint"
				});
			},
			// 将逻辑抽离到了vuex中
			// async getStatistic() {
			// 	let data = await this.$Request({
			// 		method: "POST",
			// 		url: '/passenger/getStatistic',
			// 		data: {
			// 			"pid": this.pid
			// 		}
			// 	});
			// 	if (data.errCode == 0) {
			// 		this.statistic = data.data
			// 	}
			// },
			// async recharge() {
			// 	let data = await this.$Request({
			// 		method: "POST",
			// 		url: '/passenger/recharge',
			// 		data: {
			// 			"pid": this.pid,
			// 			"charge":100
			// 		}
			// 	});
			// 	if (data.errCode == 0) {
			// 		uni.showModal({
			// 			title:"充值成功",
			// 			content:"充值金额为100元"
			// 		})
			// 		this.fetchUserInfo()
			// 	}
			// },
			// toCouponMarket() {
			// 	uni.navigateTo({
			// 		url: "/pages/couponMarket/couponMarket"
			// 	});
			// },
			registerCar(){
				uni.navigateTo({
					url: "/pages/registerCar/registerCar?did="+this.did
				});
			},
			toApprise(){
				uni.navigateTo({
					url:"/pages/AppriseList/AppriseList"
				})
			},
			toFinishRide() {
				uni.navigateTo({
					url: "/pages/finishRide/finishRide"
				});
			},
			toCoupon() {
				uni.navigateTo({
					url: '/pages/coupons/coupons'
				});
			},
			async selectImageUrl() {
				let res = await this.$u.api.selectImageUrl({
					params: {
						user: this.userInfo.name
					}
				})
				this.image = res.data.data
				console.log("this.image ", this.image)
			},
			quit(){
				this.logout()
				uni.reLaunch({
					url:"/pages/login/login"
				})
			}
		}
	};
</script>

<style scoped lang="scss">
	Page {
		font-size: 14px;
	}

	.top {
		width: 100%;
		height: 130px;
		background: #23EBB9;
		padding-top: 15px;
		position: relative;
	}

	.center {
		width: 95%;
		height: 100px;
		background: white;
		display: flex;
		flex-direction: column;
		margin: 0 auto;
		border-radius: 5px;
	}

	.center_top {
		display: flex;
		flex-direction: row;
		width: 80%;
		height: 80px;
		margin: 0 auto;
		margin-top: 20rpx;
		border-bottom: 1px solid #EEEEEE;
	}

	.center_img {
		width: 66px;
		height: 66px;
		border-radius: 50%;
		overflow: hidden;
	}

	.center_img image {
		width: 100%;
		height: 100%;
		border-radius: 50%;
	}

	.center_img .user_head {
		width: 100%;
		height: 100%;
	}

	.center_info {
		display: flex;
		flex-direction: column;
		margin-top: 20rpx;
		margin-left: 30px;
	}

	.center_name {
		font-size: 20px;
	}

	.center_phone {
		color: #BEBEBE;
	}

	// .center_down {
	// 	display: flex;
	// 	flex-direction: row;
	// 	width: 80%;
	// 	height: 35px;
	// 	margin: 0 auto;
	// 	margin-top: 20rpx;
	// }

	.center_rank {
		width: 50%;
		height: 35px;
		display: flex;
		flex-direction: row;
	}

	.rank_text {
		height: 35px;
		line-height: 35px;
		margin-left: 10rpx;
		color: #AAAAAA;
	}

	.center_vip image {
		width: 25px;
		height: 25px;
		margin-top: 15rpx;
	}

	.vip_icon {
		width: 25px;
		height: 25px;
		margin-top: -10rpx;
	}

	.vip_text {
		margin-top: -55rpx;
		margin-left: 50rpx;
		color: #AAAAAA;
	}

	.center_rank image {
		width: 35px;
		height: 35px;
	}

	.center_score {
		width: 50%;
		height: 35px;
		display: flex;
		flex-direction: row;
	}

	.center_score image {
		width: 35px;
		height: 35px;
	}

	.gif-wave {
		position: absolute;
		width: 100%;
		bottom: 0;
		left: 0;
		z-index: 99;
		mix-blend-mode: screen;
		height: 100rpx;
	}

	.wrapper {
		position: absolute;
		top: 0;
		bottom: 0;

		width: 100%;
		background-color: #F4F4F4;
	}

	.profile {
		height: 375rpx;
		background-color: #ea4451;
		display: flex;
		justify-content: center;
		align-items: center;

		.meta {
			.avatar {
				display: block;
				width: 140rpx;
				height: 140rpx;
				border-radius: 50%;
				border: 2rpx solid #fff;
				overflow: hidden;
			}

			.nickname {
				display: block;
				text-align: center;
				margin-top: 20rpx;
				font-size: 30rpx;
				color: #fff;
			}
		}
	}

	.count {
		display: flex;
		margin: 0 20rpx;
		height: 120rpx;
		text-align: center;
		border-radius: 4rpx;
		background-color: #fff;

		position: relative;
		top: 10rpx;

		.cell {
			margin-top: 10rpx;
			flex: 1;
			padding-top: 20rpx;
			font-size: 27rpx;
			color: #333;
		}

		text {
			display: block;
			font-size: 24rpx;
		}
	}

	.orders {
		margin: 20rpx 20rpx 0 20rpx;
		padding: 40rpx 0;
		background-color: #fff;
		border-radius: 4rpx;

		.title {
			padding-left: 20rpx;
			font-size: 30rpx;
			color: #333;
			padding-bottom: 20rpx;
			border-bottom: 1rpx solid #eee;
			margin-top: -30rpx;
		}

		.sorts {
			padding-top: 30rpx;
			text-align: center;
			display: flex;
		}

		[class*="icon-"] {
			flex: 1;
			font-size: 24rpx;

			&::before {
				display: block;
				font-size: 48rpx;
				margin-bottom: 8rpx;
				color: #ea4451;
			}
		}
	}

	.address {
		line-height: 1;
		background-color: #fff;
		font-size: 30rpx;
		padding: 25rpx 0 25rpx 20rpx;
		margin: 10rpx 20rpx;
		color: #333;
		border-radius: 4rpx;
	}

	.extra {
		margin: 0 20rpx;
		background-color: #fff;
		border-radius: 4rpx;

		.item {
			line-height: 1;
			padding: 25rpx 0 25rpx 20rpx;
			border-bottom: 1rpx solid #eee;
			font-size: 30rpx;
			color: #333;
		}

		button {
			text-align: left;
			background-color: #fff;

			&::after {
				border: none;
				border-radius: 0;
			}
		}
	}

	.icon-arrow {
		position: relative;

		&::before {
			position: absolute;
			top: 50%;
			right: 20rpx;
			transform: translateY(-50%);
		}
	}
</style>
