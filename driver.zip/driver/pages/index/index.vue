<template>
	<view>
		<uni-card :is-shadow="false" is-full>
			<text class="uni-h6">车辆列表，点列表项开始接单</text>
		</uni-card>
		<uni-section title="车辆列表" type="line">
			<view v-for="car in cars" :key="car.license" @click="toFindRide(car)">
				<uni-card :title="car.license">
					<text class="uni-body">汽车品牌: {{car.brand}}</text>
					<br />
					<text class="uni-body">车身颜色: {{car.color}}</text>
					<br />
					<text class="uni-body">注册时间: {{car.createTime}}</text>
					<br />
				</uni-card>
			</view>
		</uni-section>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex'
	export default {
		computed: {
			...mapState(["did"])
		},
		data() {
			return {
				cars: [],

			}
		},
		created() {
			this.getCars()
			this.checkCurrentRide()
			// return this.$getLocation()
			uni.getLocation({
				type: 'wgs84',
				success: (res) => {
					console.log(res);
				},
				complete: (res) => {
					console.log(res);
				}
			})
		},

		methods: {
			toFindRide(car) {
				
				uni.reLaunch({
					url: "/pages/findRide/findRide?license=" + car.license
				})
			},
			async getCars() {
				let data = await this.$Request({
					method: "POST",
					url: '/getCars',
					data: {
						did: this.did,
					}
				})
				if (data.errCode == 0) {
					this.cars = data.data
				}
			},
			async checkCurrentRide() {
				let data = await this.$Request({
					method: "POST",
					url: '/getCurrentRide',
					data: {
						did: this.did,
					}
				})
				if (data.errCode == 0) {
					let license = data.data.license
					uni.showModal({
						title: "检查到正在进行订单",
						content: "点击确认前往",
						success: (res) => {

							uni.navigateTo({
								url: "/pages/ridePage/ridePage?license" + license
							})
						}
					})
				}
			}
		}
	}
</script>

<style>

</style>
