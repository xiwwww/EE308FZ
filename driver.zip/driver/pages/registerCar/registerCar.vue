<template>
	<view>
		<uni-card :is-shadow="false" is-full>
			<text class="uni-h6">填写您车辆的基本信息</text>
		</uni-card>
		<uni-section title="司机ID" type="line" padding>
			<uni-easyinput :disabled="true" v-model="form.did" @input="input"></uni-easyinput>
		</uni-section>
		<uni-section title="车牌号" type="line" padding>
			<uni-easyinput v-model="form.license" placeholder="请输入内容" @input="input"></uni-easyinput>
		</uni-section>
		<uni-section title="颜色" type="line" padding>
			<uni-easyinput v-model="form.color" placeholder="请输入内容" @input="input"></uni-easyinput>
		</uni-section>
		<uni-section title="品牌" type="line" padding>
			<uni-easyinput v-model="form.brand" focus placeholder="请输入内容" @input="input"></uni-easyinput>
		</uni-section>
		<button @click="submit()">Submit</button>
	</view>
</template>

<script>
	export default {
		onLoad: function(option) { //option为object类型，会序列化上个页面传递的参数
			this.form.did = option.did
		},
		data() {
			return {
				form: {
					license: null,
					color: null,
					did: null,
					brand: null
				}
			};
		},

		methods: {
			validate() {
				// console.log(this.form);
				if (this.form.license == null || this.form.did == null || this.form.color == null || this.form.brand ==
					null) {
					return false
				} else {
					return true
				}
			},
			async submit() {
				if (this.validate()) {
					let data = await this.$Request({
						method: "POST",
						url: '/registerCar',
						data: this.form
					});
					if (data.errCode == 0) {
						uni.navigateBack()
					}
				} else {
					uni.showModal({
						title: "数据错误",
						content: "数据不可空缺"
					})
				}
			}
		}
	}
</script>

<style lang="scss">

</style>
