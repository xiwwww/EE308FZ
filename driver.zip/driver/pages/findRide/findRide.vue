<template>
	<uni-card :is-shadow="false" is-full>
		<text class="uni-h6">正在为您寻找附近合适的订单</text>
	</uni-card>
	<uni-section title="车牌号" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="form.car.license">
		</uni-easyinput>
	</uni-section>
	<uni-section title="车身颜色" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="form.car.color">
		</uni-easyinput>
	</uni-section>
	<uni-section title="品牌" type="line" padding>
		<uni-easyinput class="uni-mt-5" disabled="" v-model="form.car.brand">
		</uni-easyinput>
	</uni-section>
	<uni-section title="您的评分" type="line" padding>
		<uni-rate allow-half :value="statistic.driverRate" disabled="true" />
	</uni-section>
	<button @click="quit()">取消</button>

</template>

<script>
	import {
		mapState
	} from 'vuex'

	export default {
		onLoad: function(option) {
			// console.log(option);
			this.initCarInfo(option.license)
			// this.initSearchCar()
		},
		// onHide() {
		// 	this.stopSearchCar()
		// },
		computed: {
			...mapState(["did", "blance", "name", "statistic"])
		},
		data() {
			return {
				// ws:null,
				socketOpen: false,
				cursor:null,
				form: {
					car: {
						license: '',
						color: '',
						brand: '',
						did: ''
					},
					point: {
						x: 116.99,
						y: 36.651
					}
				}
			};
		},
		methods: {
			async initCarInfo(license) {
				let data = await this.$Request({
					method: "POST",
					url: '/fetchCarInfo',
					data: {
						license: license
					}
				});
				if (data.errCode == 0) {
					this.form.car = data.data
					this.initSearchCar()
				}
			},
			async quit() {
				// await this.stopSearchCar()
				await this.stopSearchCar()
				uni.closeSocket()
				uni.reLaunch({
					url: "/pages/index/index"
				})
				clearInterval(that.cursor)
			},
			
			async stopSearchCar() {
				this.sendMessage({
					action: "stopSearchRides",
					data: {
						license: this.form.car.license
					}
				})
			},
			async initSearchCar() {
				let that = this
				//初始化查询信息，使用ws初始化连接
				uni.closeSocket()
				await uni.connectSocket({
					url: 'ws://192.168.31.214:8082/ws/carFindOrder',
					fail: (res) => {
						uni.showModal({
							title: "网络错误",
							content: "当前无法使用",
							success: (res) => {
								uni.navigateBack()
							}
						})
					},

				});
				//测试多次websocket连接下后端正常运行
				// await uni.connectSocket({
				// 	url: 'ws://192.168.31.214:8082/ws/carFindOrder',
				// 	fail: (res) => {
				// 		uni.showModal({
				// 			title: "网络错误",
				// 			content: "当前无法使用",
				// 			success: (res) => {
				// 				uni.navigateBack()
				// 			}
				// 		})
				// 	},
				
				// });
				//监听连接建立成功后
				uni.onSocketOpen(function(res) {
					that.socketOpen = true
					that.sendMessage({
						action: "initConnection",
						data:{
						license:that.form.car.license	
						}
					})
					that.sendMessage({
						action: "initSearch",
						data: that.form
					})
					that.cursor = setInterval(() => {
						//更新车辆位置信息
						that.sendMessage({
							action: "updateCarPos",
							data: that.form
						})
					}, 5000)
				});
				uni.onSocketClose((res)=>{
					clearInterval(that.cursor)
				})
				uni.onSocketMessage(function(res) {
					console.log('收到服务器内容：' + res.data);
					let data = JSON.parse(res.data);
					if (data.action == "rideReady") {
						clearInterval(that.cursor)
						uni.showModal({
							title: "检查到正在进行订单",
							content: "点击确认前往",
							success: (res) => {
								uni.navigateTo({
									url: "/pages/ridePage/ridePage?license=" + that.form.car.license
								})
							}
						})
					} 
				});


			},
			//传递json类型的字符串{string:action,data:data}
			async sendMessage(object) {
				let message = JSON.stringify(object)
				if (this.socketOpen) {
					console.log(message);
					uni.sendSocketMessage({
						data: message,
					});
				}
			}
		}
	}
</script>

<style lang="scss">
	button {
		width: 50%;
		margin: 0 auto;
	}

	.example-body {
		background-color: #fff;
		padding: 10px;
	}

	.text {
		font-size: 12px;
		color: #666;
		margin-top: 5px;
	}

	.uni-px-5 {
		padding-left: 10px;
		padding-right: 10px;
	}

	.uni-pb-5 {
		padding-bottom: 10px;
	}
</style>
