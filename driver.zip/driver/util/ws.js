// // 请求服务器地址
// const baseURL = 'ws://192.168.31.214:8082'

// const createWebSocket = (options={}) => {
// 	uni.connectSocket({
// 		url: baseURL + options.url,
// 		// 请求方式（若不传，则默认为 GET ）
// 		method: options.method || 'GET',
// 		header: {
// 			'content-type': 'application/json'
// 		},
// 		protocols: ['protocol1'],
// 		fail: (res) => {
// 			console.log(res);
// 		}
// 	});
	
// }