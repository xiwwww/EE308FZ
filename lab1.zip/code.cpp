	#include <stdio.h>  
	int main(){  
	    int i=1;  
	    double j=0;  
	    long f;  
	    switch(i){  
	        case 0:  
	            break;  
	        case 1:  
	            break;  
	        case 2:  
	            break;  
	        default:  
	            break; 
		   }  

